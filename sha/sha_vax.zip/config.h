#ifndef _CONFIG_H
# define _CONFIG_H


#define THIRTY_TWO_BIT
#endif
